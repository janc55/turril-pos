<?php

namespace App\Filament\Resources\CashBoxResource\Pages;

use App\Filament\Resources\CashBoxResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCashBox extends CreateRecord
{
    protected static string $resource = CashBoxResource::class;
}
